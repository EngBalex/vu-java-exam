/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.evening;

/**
 *
 * @author Eng. Balex
 */
public class ifs {
    
    public static void main(String [] args){
        //Using if statement
        int a = 9;
        if(a%2 == 0){
            System.out.println(a + " is an Even");
        }
        else{
            System.out.println(a + " is an Odd");
            
        }
    }
    
}
