/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vu.evening;

/**
 *
 * @author Eng. Balex
 */ 
public class Evening {

        public static void main(String [] args){
            
            System.out.print("Good Evening Members \t"); //This prints  but the next printing will begin on the same line
            
            
            System.out.println("Good Evening Members");//This prints  but the next printing will begin on the next line
            
            System.out.println("Our coding begins today");
            
            
            
            //Comments
            /*
            Single Line COmment  //
            
            Multi-Line COmment /*
            
            
                               */
            /*
            */
        }
}
