/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.evening;

/**
 *
 * @author Eng. Balex
 */
public class operators {
    public static void main(String [] args){
         
    int no1 =25;
    int no2 =35;
    int sum =  no1 +  no2;
    System.out.println("The sum is " + sum);
    int sub =no2-no1;
    System.out.println("The sub is " + sub);
    int times = no2*no1;
    System.out.println("When "+no1 + " is multiplied by "+no2+ " we get " +times );
    int mod =no2%no1;
    
    System.out.println("When "+no2 + " is divided by "+no1+ " we get a reminder  of " +mod );
    
    
    
    //operators and operands
    //Arithmetic Operators
       /* Addition +
                Substraction -
                Division /
                        Multplication   *
                        Modulus  % = 10%3  =1
       */
  
    
}
}