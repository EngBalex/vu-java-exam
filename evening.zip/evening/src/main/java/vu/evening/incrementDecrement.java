/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.evening;

/**
 *
 * @author Eng. Balex
 */
public class incrementDecrement {
    public static void main(String [] main){
        /*
        Increment  ++   Pre  and        Post
        Decrement --    pre     and     Post
        
        int x =10;
        Increments
        x++;   //Post 10
        ++x;    //Pre 11
        
        Decrements
        x--;   //Post  10
        --x;    //Pre   9       
        
        */
        int x =10;
        System.out.println(++x);
                
    }
    
}
