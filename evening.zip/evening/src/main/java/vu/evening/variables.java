/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.evening;

/**
 *
 * @author Eng. Balex
 */
public class variables {
    public static void main(String [] args){
        //Variables Declaration 
        int age;
        int a,b,c;
        String name; 
        
        //Variable Initialization
        name = "Drapari Fred";
        age = 30;
        
       //OUTPUT
       System.out.println(age);
       
       
       System.out.println("My Name is " + name + " and am " +age + " years old ");
        
        
    }
    
}
