/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.evening;

/**
 *
 * @author Eng. Balex
 */
public class loops {
    //for loops
    //do while loops
    // while loops
    // foreach loops
    
//  for(declaration and initialization; range; increment | decrement){
    
//}
    public static void main(String [] args){    
        System.out.println("Even Numbers between 10 and 40");
               /* for(int a = 10; a<=40; a++){
                    if(a%2==0){
                              System.out.print(a +" , ");
                    }
            }
*/
             
               //do while loops
            /*   int no = 10;
               do {
                   if(no%2 ==0){                       
                   System.out.print(no + " , ");
                   }
                   no++;
               }
               while(no<=40);
*/
            
            int no =10;
            while(no<=40){
                 if(no%2 ==0){                       
                   System.out.print(no + " , ");
                   }
                   no++;
            }
    
    }
}
