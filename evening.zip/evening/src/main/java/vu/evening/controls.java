/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vu.evening;

/**
 *
 * @author Eng. Balex
 */
public class controls {
   /* 
 1.  using if statements
    
 if (condition){
    Block statements
}
    
2. if and else statements    
    if (True condition){
    block statements if True
}
    else{
    False
    
}
    
   3. if else if and else statements
    
    if(condition){
    }
    else if(condition){
    
    }
    
    else{
    }
    
    4. Switch statement
    
    switch(int a){
    case 1:
    System.out.println();
    break;
    
    case 2:
    System.out.println();
    break;
    
    case 3:
    System.out.println();
    break;
    
    Default:
    System.out.println();
    break;
    
    }
    
    Program checks whether a number is even or odd and others
    
    */
}
