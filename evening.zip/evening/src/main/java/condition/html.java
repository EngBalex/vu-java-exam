/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package condition;

/**
 *
 * @author Eng. Balex
 */
public class html {
    public static void main(String [] args){
        /*
        Comparisonal /Logical Conditional Operators
      
        Less Than <
        LessThan or Equal <=
        Greater Than >
        Greater Tha  or Equal >=
        Equals ==
        Assignment =
        Not Equals !=
        
        */
         int a = 20;
        int b = 25;
        boolean isEquals  = a==b; //Either True or False
        System.out.println(isEquals);
        boolean isLessThan = a<b;
        System.out.println(isLessThan);
        
    }
    
}
